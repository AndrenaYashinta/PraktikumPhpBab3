 <?php
include'koneksi.php';
$id=$_GET['id'];
mysqli_query($koneksi,"DELETE FORM user1 WHERE id='$id'");
header("localtion.index.php?pesan=hapus");
?>