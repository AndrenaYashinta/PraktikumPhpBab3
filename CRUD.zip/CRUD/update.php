<?php 
include'koneksi.php';
$id=$_POST['id'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$pekerjaan=$_POST['pekerjaan'];

mysqli_query("UPDATE user1 name='$nama', alamat='$alamat', pekerjaan='$pekerjaan' WHERE id='$Id'"); 

header("location:index.php?pesan=update");
?>